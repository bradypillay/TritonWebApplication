﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TritonWebApplication.Models;

namespace TritonWebApplication.Controllers
{
    public class storagesController : Controller
    {
        private readonly TritonWebApplicationContext _context;
        
        public storagesController(TritonWebApplicationContext context)
        {
            _context = context;
        }

        // GET: storages
        public async Task<IActionResult> Index(string searchString)
        {

        
            if (!String.IsNullOrEmpty(searchString))
            {
                var storageItems = (from s in _context.storage
                                    where s.StorageLocation.Contains(searchString) ||
                                          s.StorageName.Contains(searchString)
                                    select s);

                return View(await storageItems.ToListAsync());
            }
            else
            {
                var storageItems = from s in _context.storage select s;
                return View(await storageItems.ToListAsync());
            }
        }

        // GET: storages/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var storage = await _context.storage
                .FirstOrDefaultAsync(m => m.storageID == id);
            if (storage == null)
            {
                return NotFound();
            }

            return View(storage);
        }

        // GET: storages/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: storages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("storageID,StorageName,StorageLocation")] storage storage)
        {
            if (ModelState.IsValid)
            {
                _context.Add(storage);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(storage);
        }

        // GET: storages/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var storage = await _context.storage.FindAsync(id);
            if (storage == null)
            {
                return NotFound();
            }
            return View(storage);
        }

        // POST: storages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("storageID,StorageName,StorageLocation")] storage storage)
        {
            if (id != storage.storageID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(storage);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!storageExists(storage.storageID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(storage);
        }

        // GET: storages/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var storage = await _context.storage
                .FirstOrDefaultAsync(m => m.storageID == id);
            if (storage == null)
            {
                return NotFound();
            }

            return View(storage);
        }

        // POST: storages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var storage = await _context.storage.FindAsync(id);
            _context.storage.Remove(storage);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool storageExists(int id)
        {
            return _context.storage.Any(e => e.storageID == id);
        }
    }
}
