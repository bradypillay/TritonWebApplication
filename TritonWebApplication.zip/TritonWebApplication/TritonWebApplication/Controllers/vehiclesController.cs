﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TritonWebApplication.Models;

namespace TritonWebApplication.Controllers
{
    public class vehiclesController : Controller
    {
        private readonly TritonWebApplicationContext _context;

        public vehiclesController(TritonWebApplicationContext context)
        {
            _context = context;
        }

        // GET: vehicles
        
        public async Task<IActionResult> Index(string searchString)
        {

            
            if (!String.IsNullOrEmpty(searchString))
            {
                var vehicles = (from s in _context.vehicles.Include(w => w.Storage)
                                where s.VehicleBranch.Contains(searchString) ||
                                      s.VehicleLicense.Contains(searchString) ||
                                      s.VehicleModel.Contains(searchString) ||
                                      s.VehicleMake.Contains(searchString)
                                select s);

                return View(await vehicles.ToListAsync());
            }
            else
            {
                
                var tritonWebApplicationContext = _context.vehicles.Include(w => w.Storage);
                return View(await tritonWebApplicationContext.ToListAsync());
            }

            
        }

        // GET: vehicles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicles = await _context.vehicles
                .Include(v => v.Storage)
                .FirstOrDefaultAsync(m => m.VehicleID == id);
            if (vehicles == null)
            {
                return NotFound();
            }

            return View(vehicles);
        }

        // GET: vehicles/Create
        public IActionResult Create()
        {
            ViewData["storageID"] = new SelectList(_context.storage, "storageID", "StorageName");
            return View();
        }

        // POST: vehicles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VehicleID,VehicleMake,VehicleModel,VehicleBranch,VehicleLicense,storageID")] vehicles vehicles)
        {
            if (ModelState.IsValid)
            {
                _context.Add(vehicles);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["storageID"] = new SelectList(_context.storage, "storageID", "StorageName", vehicles.storageID);
            return View(vehicles);
        }

        // GET: vehicles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicles = await _context.vehicles.FindAsync(id);
            if (vehicles == null)
            {
                return NotFound();
            }
            ViewData["storageID"] = new SelectList(_context.storage, "storageID", "StorageName", vehicles.storageID);
            return View(vehicles);
        }

        // POST: vehicles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VehicleID,VehicleMake,VehicleModel,VehicleBranch,VehicleLicense,storageID")] vehicles vehicles)
        {
            if (id != vehicles.VehicleID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vehicles);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!vehiclesExists(vehicles.VehicleID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["storageID"] = new SelectList(_context.storage, "storageID", "StorageName", vehicles.storageID);
            return View(vehicles);
        }

        // GET: vehicles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vehicles = await _context.vehicles
                .Include(v => v.Storage)
                .FirstOrDefaultAsync(m => m.VehicleID == id);
            if (vehicles == null)
            {
                return NotFound();
            }

            return View(vehicles);
        }

        // POST: vehicles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vehicles = await _context.vehicles.FindAsync(id);
            _context.vehicles.Remove(vehicles);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool vehiclesExists(int id)
        {
            return _context.vehicles.Any(e => e.VehicleID == id);
        }
    }
}
