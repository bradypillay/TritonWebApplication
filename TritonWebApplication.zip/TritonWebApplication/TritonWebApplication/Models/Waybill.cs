﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TritonWebApplication.Models
{
    public class Waybill
    {
        [Key]
        public int WaybillID { get; set;}

        [DisplayName("Waybill Number")]
        public string WaybillNo { get; set; }

        [DisplayName("Package Weight (KG)")]
        public string Weight { get; set; }

        [DisplayName("Number of Packages")]
        public string PackageNo { get; set; }

        [DisplayName("Assign Vehicle")]
        public int VehicleID { get; set; }
        public vehicles Vehicles { get; set; }

    }
}
