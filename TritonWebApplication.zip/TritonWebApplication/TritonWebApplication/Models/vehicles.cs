﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace TritonWebApplication.Models
{
    public class vehicles
    {
        [Key]
        public int VehicleID { get; set; }

        [DisplayName("Vehicle Make")]
        public string VehicleMake { get; set; }

        [DisplayName("Vehicle Model")]
        public string VehicleModel { get; set; }

        [DisplayName("Vehicle Milage")]
        public string VehicleBranch { get; set; }

        [DisplayName("Vehicle License Plate Number")]
        public string VehicleLicense { get; set; }

        [DisplayName("Vehicle Branch")]
        public int storageID { get; set; }
        public storage Storage { get; set;   }

    }
}
