﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TritonWebApplication.Models
{
    public class storage
    {
        [Key]
        public int storageID { get; set; }

        [DisplayName("Storage Name")]
        public string StorageName { get; set; }

        [DisplayName("Location")]
        public string StorageLocation { get; set; }

        public ICollection<vehicles> vehicles { get; set; }


    }
}
