﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TritonWebApplication.Models;

namespace TritonWebApplication.Models
{
    public class TritonWebApplicationContext : DbContext
    {
        public TritonWebApplicationContext (DbContextOptions<TritonWebApplicationContext> options)
            : base(options)
        {
        }

        public TritonWebApplicationContext()
        {
        }

        public DbSet<TritonWebApplication.Models.storage> storage { get; set; }

        public DbSet<TritonWebApplication.Models.vehicles> vehicles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<storage>().ToTable("storage");
            modelBuilder.Entity<vehicles>().ToTable("vehicles");
        }

        public DbSet<TritonWebApplication.Models.Waybill> Waybill { get; set; }
    }
}
